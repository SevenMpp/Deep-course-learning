from opencc import OpenCC
import os
#繁转简
c = OpenCC('t2s')
target = r'F:\资料\项目\wikiextractor-master\wiki.TTS.text' # 转化后的保存目录
path = r'F:\资料\项目\wikiextractor-master\wiki.cn.text' 
if not os.path.exists(target):
    os.makedirs(target)
for i in os.listdir(r'F:\资料\项目\wikiextractor-master\wiki.cn.text'):
     dirname = os.path.join(path, i)
     target_dirname = os.path.join(target, i)
     if not os.path.exists(target_dirname):
         os.makedirs(target_dirname)
     for filename in os.listdir(dirname):
         paths = os.path.join(dirname,filename)
         with open(paths, 'r', encoding='utf-8') as f:
             line = f.readlines()
             for k in line:
                text_l = k.strip()
                target_path = os.path.join(target_dirname,filename)
                with open(target_path, 'a+', encoding='utf-8') as f1:
                    print("正在提取{}中的{}".format(i, filename))
                    data_new = c.convert(text_l)
                    f1.write(data_new + '\n')

