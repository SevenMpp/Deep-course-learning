import logging, jieba, os, re ,codecs,opencc

def get_stopwords():
    logging.basicConfig(format='%(asctime)s:%(levelname)s:%(message)s', level=logging.INFO)
    # 加载停用词表
    stopword_set = set()
    with open("F:\资料\项目\wikiextractor-master\stop_words.txt", 'r', encoding="utf-8") as stopwords:
        for stopword in stopwords:
            stopword_set.add(stopword.strip("\n"))
    return stopword_set
path = r'F:\资料\项目\wikiextractor-master\wiki.zh.text'
#regex_str = ">\w.*</doc>"
pattern = re.compile(r'[\u4e00-\u9fa5]')
#opencc
target = r'F:\资料\项目\wikiextractor-master\wiki.cn.text'
if not os.path.exists(target):
    os.makedirs(target)
#if not os.path.exists(target):
    #os.makedirs(target,mode=0o777)
#cc = opencc.OpenCC('t2s')  #mix2s - Mixed to Simplified Chinese
for i in os.listdir(r'F:\资料\项目\wikiextractor-master\wiki.zh.text'):
     dirname = os.path.join(path, i)
     target_dirname = os.path.join(target, i)
     #print(dirname)
     if not os.path.exists(target_dirname):
         os.makedirs(target_dirname)
     for filename in os.listdir(dirname):
         paths = os.path.join(dirname,filename)
         with open(paths, 'r', encoding='utf-8') as f:
             line = f.readlines()
             for k in line:
                text = re.findall(pattern, k)
                text_l = ''.join(text).strip()
                target_path = os.path.join(target_dirname,filename)
                #print(text_l)
                with open(target_path, 'a+', encoding='utf-8') as f1:
                    print("正在提取{}中的{}".format(i, filename))
                        #print(j.strip('\n'))
                    if len(text_l) == 0:
                        continue

                    #print(text_l)
                    f1.write(text_l + '\n')
