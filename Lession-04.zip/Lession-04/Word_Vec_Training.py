from gensim.models.word2vec import Word2Vec,LineSentence
import jieba

import os
import time
def stopwords():
    stopwords_path = r'F:\资料\项目\stopwords.txt'
    stopwords = [line.strip() for line in open(stopwords_path, 'r', encoding='utf-8').readlines()]
    return stopwords

path = r'F:\资料\项目\wikiextractor-master\wiki.TTS.text'
target_path = r'F:\资料\项目\wikiextractor-master\Simple.txt'  #分词后保存的文件地址
model_path = r'F:\资料\项目\wikiextractor-master\word2vec.model'

def seg():
    for i in os.listdir(r'F:\资料\项目\wikiextractor-master\wiki.cn.text'):
         dirname = os.path.join(path, i)
         print(dirname)
         for filename in os.listdir(dirname):
             paths = os.path.join(dirname,filename)
             with open(paths, 'r', encoding='utf-8') as f:
                 line = f.readlines()
                 for k in line:
                    text_l = k.strip()
                    with open(target_path, 'a+', encoding='utf-8') as f1:
                       # print("正在提取{}中的{}".format(i, filename))
                        text_2 =jieba.lcut(text_l.strip())
                        outstr = ''
                        for word in text_2:
                            if word not in stopwords():
                                if word != '\t':
                                    outstr += word
                                    outstr += " "

                        #f1.write(outstr + '\n')
#seg()

def Word_train():
    text_crouse = LineSentence(target_path)
    print('开始。。。。。。。')
    model = Word2Vec(sentences=text_crouse, size=200, window=5, min_count=500, sg=0, hs=1)
    print("保存。。。。。。。。。。。。。。")

    model.save(model_path)
    print("结束。。。。。。。。。。。。。。")
#Word_train()
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE

import matplotlib
def tsne_plot(mode_path):

    model = Word2Vec.load(model_path)
    matplotlib.rcParams['font.family'] = 'Simhei'
    "Creates and TSNE model and plots it"
    labels = []
    tokens = []

    for word in model.wv.vocab:
        tokens.append(model[word])
        labels.append(word)
    tsne_model = TSNE(perplexity=40, n_components=2, init='pca', n_iter=2500, random_state=23)
    plot_only = 500
    new_values = tsne_model.fit_transform(tokens[:500])

    x = []
    y = []
    for value in new_values:
        x.append(value[0])
        y.append(value[1])

    plt.figure(figsize=(16, 16))
    for i in range(len(x)):
        plt.scatter(x[i], y[i])
        plt.annotate(labels[i],
                     xy=(x[i], y[i]),
                     xytext=(5, 2),
                     textcoords='offset points',
                     ha='right',
                     va='bottom')
    plt.show()


tsne_plot(model_path)

