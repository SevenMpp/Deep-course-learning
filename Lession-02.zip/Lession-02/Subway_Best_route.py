#--*-- coding: utf-8 --*--
from collections import defaultdict
import matplotlib.pyplot as plt
import networkx as nx
list1 = []
list2 = []
def search(start, destination, connection_grpah,sort_candidate):
    pathes = [[start]]
    visitied = set()
    while pathes:  # if we find existing pathes
        path = pathes.pop(0)
        froninter = path[-1]
        if froninter in visitied: continue
        successors = connection_grpah[froninter]
        for city in successors:
            if city in path: continue  # eliminate loop
            new_path = path + [city]
            pathes.append(new_path)
            if city == destination: return new_path
        visitied.add(froninter)
        pathes = sort_candidate(pathes)
def transfer_stations_first(pathes):  #最少换乘
    return sorted(pathes, key=len,reverse=True)
def shortext_path_first(pathes): #没做出来
    Site_direct_distance = {'北京地铁4号线', '北京地铁14号线', '北京地铁15号线', '北京地铁1号线',
                             '北京地铁8号线', '北京地铁7号线', '北京地铁16号线', '北京地铁5号线',
                             '北京地铁9号线', '北京地铁6号线', '北京地铁13号线', '北京地铁2号线',
                             '北京地铁10号线', '西郊线', '房山线', '八通线',
                             '昌平线', '机场线', '燕房线', '大兴线', '亦庄线'}
    if len(pathes) <=1:return pathes

with open('site.txt','r',encoding='utf-8') as f: #读取站点信息并生成defaultdict(<class 'list'>形式
    for index,text in enumerate(f.readlines()):
        if index % 2 ==0:
           list1.append(text.strip())
        else:
            list2.append(text.strip())

    site_dic = dict(zip(list1,list2))
    site_location = []
    city_connection = defaultdict(list)
def extend_site1():  # OK
    new_list = []
    for i in site_dic.values():
        line_site = i.replace("[", '').replace("]", '').replace("'", '').strip().lstrip().split(",")
        for j in line_site:
            new_list.append(j)
    # print(new_list)
    for index1,c1 in enumerate(new_list):
        c1 = c1.strip()
        #print(c1)
        for index2,c2 in enumerate(new_list):
            c2 = c2.strip()
            if c1 == c2: continue
            if index1 + 1 == index2 :
                city_connection[c1].append(c2)
                city_connection[c2].append(c1)
    return city_connection
def extend_site():# 没有换乘站之间的关系,未扩展出来
    for i in site_dic.values():
        line_site = i.replace("[",'').replace("]",'').replace("'",'').strip().lstrip().split(",")
        for index,j in enumerate(line_site):
            if index + 1 < len(line_site):
                if line_site[index].strip() != line_site[index + 1].strip():
                    city_connection[line_site[index].strip()] = [line_site[index + 1].strip()]
                    city_connection[line_site[index + 1].strip()] = [line_site[index].strip()]
    return city_connection

print(search('角门西站', '次渠站',extend_site1(),sort_candidate=transfer_stations_first))
