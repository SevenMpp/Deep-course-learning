import matplotlib
coordination_source = """
{name:'兰州', geoCoord:[103.73, 36.03]},
{name:'嘉峪关', geoCoord:[98.17, 39.47]},
{name:'西宁', geoCoord:[101.74, 36.56]},
{name:'成都', geoCoord:[104.06, 30.67]},
{name:'石家庄', geoCoord:[114.48, 38.03]},
{name:'拉萨', geoCoord:[102.73, 25.04]},
{name:'贵阳', geoCoord:[106.71, 26.57]},
{name:'武汉', geoCoord:[114.31, 30.52]},
{name:'郑州', geoCoord:[113.65, 34.76]},
{name:'济南', geoCoord:[117, 36.65]},
{name:'南京', geoCoord:[118.78, 32.04]},
{name:'合肥', geoCoord:[117.27, 31.86]},
{name:'杭州', geoCoord:[120.19, 30.26]},
{name:'南昌', geoCoord:[115.89, 28.68]},
{name:'福州', geoCoord:[119.3, 26.08]},
{name:'广州', geoCoord:[113.23, 23.16]},
{name:'长沙', geoCoord:[113, 28.21]},
//{name:'海口', geoCoord:[110.35, 20.02]},
{name:'沈阳', geoCoord:[123.38, 41.8]},
{name:'长春', geoCoord:[125.35, 43.88]},
{name:'哈尔滨', geoCoord:[126.63, 45.75]},
{name:'太原', geoCoord:[112.53, 37.87]},
{name:'西安', geoCoord:[108.95, 34.27]},
//{name:'台湾', geoCoord:[121.30, 25.03]},
{name:'北京', geoCoord:[116.46, 39.92]},
{name:'上海', geoCoord:[121.48, 31.22]},
{name:'重庆', geoCoord:[106.54, 29.59]},
{name:'天津', geoCoord:[117.2, 39.13]},
{name:'呼和浩特', geoCoord:[111.65, 40.82]},
{name:'南宁', geoCoord:[108.33, 22.84]},
//{name:'西藏', geoCoord:[91.11, 29.97]},
{name:'银川', geoCoord:[106.27, 38.47]},
{name:'乌鲁木齐', geoCoord:[87.68, 43.77]},
{name:'香港', geoCoord:[114.17, 22.28]},
{name:'澳门', geoCoord:[113.54, 22.19]}
"""
import matplotlib.pyplot as plt
import networkx as nx
import re
import math
city_location = {}  #用于保存城市与对应经纬度
pattern = re.compile(r"name:'(\w+)',\s+geoCoord:\[(\d+.\d+),\s(\d+.\d+)\]")
for line in coordination_source.split('\n'):

    city_info = pattern.findall(line)
    #print(city_info)
    if not city_info: continue

    #following: we find the city info
    #print(city_info)
    city, long, lat = city_info[0]

    long, lat = float(long), float(lat)  #转化成浮点类型用于计算
    city_location[city] = (long, lat)
#print(city_location)
def get_distance(origin, destination): #计算距离
    lat1,lon1 = origin
    lat2,lon2 = destination
    radius = 6371  #地球半径
    dlat = math.radians(lat2 - lat1) #经度之差
    dlon = math.radians(lon2 - lon1) #纬度之差
    a = (math.sin(dlat /2) * math.sin(dlat /2) +
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
         math.sin(dlon /2) * math.sin(dlon /2))
    c = 2 * math.atan2(math.sqrt(a),math.sqrt(1 - a))
    d = radius * c
    return d
def get_city_distance(city1, city2): #计算两城之间距离
    return get_distance(city_location[city1], city_location[city2])
#print(get_city_distance('杭州', '上海'))
cities = list(city_location.keys())
#print("citise is:", cities)
city_graph = nx.Graph()
city_graph.add_nodes_from(cities)
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
nx.draw(city_graph,pos=city_location,with_labels=True,node_size = 30)
#plt.show()
def extended_city():  #每个城市的扩展结果
    threshold = 300
    from  collections import defaultdict
    city_connection = defaultdict(list)

    for c1 in cities:
        for c2 in cities:
            if c1 == c2:continue
            if get_city_distance(c1,c2) < threshold:
                city_connection[c1].append(c2)
                city_connection[c2].append(c1)    #没懂
    return city_connection
#print(extended_city())  # 每个城市的扩展
cities_connection_graph = nx.Graph(extended_city())
nx.draw(cities_connection_graph, city_location, with_labels=True, node_size=10)
plt.show()
def is_goal(desitination):
    def _wrap(current_path):
        return current_path[-1] == desitination
    return _wrap


def search(start, destination, connection_grpah, sort_candidate):
    pathes = [[start]]

    visitied = set()

    while pathes:  # if we find existing pathes
        path = pathes.pop(0)
        froninter = path[-1]

        if froninter in visitied: continue

        successors = connection_grpah[froninter]

        for city in successors:
            if city in path: continue  # eliminate loop

            new_path = path + [city]

            pathes.append(new_path)

            if city == destination: return new_path

        visitied.add(froninter)

        pathes = sort_candidate(pathes)
def transfer_stations_first(pathes):  #最少换乘
    return sorted(pathes, key=len,reverse=True)
def shortest_path_first(pathes):
    if len(pathes) <= 1: return pathes
    def get_path_distnace(path):
        distance = 0
        for station in path[:-1]:
            distance += get_city_distance(station, path[-1])
        return distance
    return sorted(pathes, key=get_path_distnace)
print("hortest_path_first is:",search('兰州', '海口', extended_city(),sort_candidate=transfer_stations_first))
