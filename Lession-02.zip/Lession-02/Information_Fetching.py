#--*-- coding: utf-8 --*--
import requests
import re
import bs4
import time
import certifi

header = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0",
          'Connection': 'close'}
def Get_line_address():  #获取每条线路的地址和名称  并保存
    #header = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0"}
    url = r"https://baike.baidu.com/item/%E5%8C%97%E4%BA%AC%E5%9C%B0%E9%93%81/408485"
    response= requests.get(url=url, headers =header)
    html = response.content.decode('utf-8','ignore')
    #print(html))
    pattern = r'href="(/item/(%[0-9a-fA-F][0-9a-fA-F])+(%[0-9]\d*)+(%[0-9a-fA-F][0-9a-fA-F])+)">(北京地铁\d+号线)' # 1-16号线路信息
    pattern1 = r'<a target=_blank href="(/item/(?:%[0-9a-fA-F][0-9a-fA-F])+)">北京地铁([\u4E00-\u9FA5]+)' # 其他线路信息
    pattern = re.compile(pattern)
    pattern1 = re.compile(pattern1) # 其他线路信息
    text = pattern1.findall(html)
    text1 = pattern.findall(html)
    test2 = []
    with open('url.txt','w',encoding='utf-8') as f:  #保存其他线路信息
        for i in set(text):#去重
            f.write(str(i).replace()+ '\n')
    with open('url.txt', 'a', encoding='utf-8') as f1: #保存1-16号线路信息
        for j in set(text1):
            f1.write(str(j) + '\n')
#Get_line_address()

def Crawl_site_information():  #抓取各线的相关站点信息
    url = "https://baike.baidu.com"
    dic = {}
    list = []
    with open('url1.txt','r',encoding='utf-8') as f2:  #url.txt 为1-16号线链接信息 url1.txt为其他线路链接信息
        for u in  f2.readlines():
            url_and_site= u.replace("('", '').replace("')", '').replace("'", '').split(",")
            #print(url_and_site)
            all_url = url+url_and_site[0]
            #print(all_url)
            response = requests.get(url=all_url,headers = header)
            html = response.content.decode('utf-8', 'ignore')
            pattern= re.compile(r'<a target=_blank href="/item/(?:%[0-9a-fA-F][0-9a-fA-F])+%99">([\u4E00-\u9FA5]+)</a>')  #匹配地铁各线站点信息
            text = pattern.findall(html)
            dic[url_and_site[1]] = text
        print(dic)
        print("Was a nice sleep, now let me continue...")
        time.sleep(10)
        print("continue")
        with open('site1.txt','a',encoding='utf-8') as f3: #保存各线路和对应的站点信息
            for key,value in dic.items():
                f3.write(key + " " + str(value) + "\n")
Crawl_site_information()