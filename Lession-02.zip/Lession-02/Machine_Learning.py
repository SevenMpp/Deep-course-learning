from sklearn.datasets import load_boston
import matplotlib.pyplot as plt
import random
data = load_boston()
X,y = data["data"],data['target']
#print(X)
#print(len(X[:, 0]))
def draw_rm_and_price():
    plt.scatter(X[:, 5], y)

def price(rm, k, b):
    """f(x) = k * x + b"""
    return k * rm + b

def loss(y, y_hat): # 差平方的平均
    return sum((y_i - y_hat_i)**2 for y_i, y_hat_i in zip(list(y), list(y_hat))) / len(list(y))
def loss_1(y,y_hat):#差绝对值的平均
    return sum(abs(y_i - y_hat_i) for y_i, y_hat_i in zip(list(y), list(y_hat))) / len(list(y))
import math
def loss_2(y, y_hat):#平衡交叉熵
    return sum(y_hat_i*math.log(1/(1 + math.exp(-y_i))) for y_i, y_hat_i in zip(list(y), list(y_hat))) / len(list(y))

trying_times = 2000 #训练次数
X_rm = X[:, 5]
def Random_Generation_k_b():
    min_loss = float('inf')
    best_k, best_b = None, None

    for i in range(trying_times):
        k = random.random() * 200 - 100
        b = random.random() * 200 - 100
        price_by_random_k_and_b = [price(r, k, b) for r in X_rm]

        current_loss = loss(y, price_by_random_k_and_b)

        if current_loss < min_loss:
            min_loss = current_loss
            best_k, best_b = k, b
            print('When time is : {}, get best_k: {} best_b: {}, and the loss is: {}'.format(i, best_k, best_b, min_loss))
#Random_Generation_k_b()
def Direction_Adjusting():
    min_loss = float("inf")
    best_k = random.random()*200 - 100
    best_b = random.random()*200 - 100
    direction = [
        (+1,-1),
        (+1,+1),
        (-1,+1),
        (-1,-1),
    ]
    next_direction = random.choice(direction)
    scalar = 0.1  # 学习率

    for i in range(trying_times):
        k_direction, b_direction = next_direction
        current_k, current_b = best_k + k_direction * scalar, best_b + b_direction * scalar
        peric_by_k_and_b = [price(r,current_k,current_b) for  r in X_rm]
        current_loss = loss(y,peric_by_k_and_b)
        if current_loss < min_loss:
            min_loss = current_loss
            best_k,best_b = current_k,current_b
            next_direction = next_direction
            print("When time is : {}, get best_k : {}, best_b: {}, and the loss is: {}".format(i,best_k,best_b,min_loss))
        else:
            next_direction = random.choice(direction)
#Direction_Adjusting()

def _partial_k(x,y,y_hat):
    n = len(y)
    gradient = 0
    for x_i,y_i,y_hat_i in zip(list(x), list(y),list(y_hat)):
        gradient +=(y_i - y_hat_i) * x_i
    return -2/ n* gradient
def _partial_b(x,y,y_hat):
    n = len(y)
    gradient = 0
    for x_i, y_i, y_hat_i in zip(list(x), list(y), list(y_hat)):
        gradient += (y_i - y_hat_i)
    return -2 / n * gradient
def supervised_learning():

    trying_times = 2000
    X, y = data["data"], data["target"]
    #print("X IS:",X)
    #print("X_rm:",X_rm)
    min_loss = float('inf')
    current_k = random.random() * 200 -100
    current_b = random.random() * 200 -100
    learning_rate = 1e-04
    for i in range(trying_times):
        price_by_k_and_b = [price(r,current_k,current_b) for r in  X_rm]
        current_loss = loss(y, price_by_k_and_b)
        if current_loss < min_loss:
            min_loss = current_loss
            if i % 100 == 0:
                print("When time is{},get best_k {}, get best {}, loss is {}".format(i, current_k, current_b, min_loss))
        k_gradient = _partial_k(X_rm, y, price_by_k_and_b)

        b_gradient = _partial_b(X_rm, y, price_by_k_and_b)

        current_k = current_k + (-1 * k_gradient) * learning_rate

        current_b = current_b + (-1 * b_gradient) * learning_rate
supervised_learning()
print(X[:4])

'''问题1、为什么把 X 作为指的时候  [price(r,current_k,current_b) for r in  X   会报错，类型有什么不同嘛 
   问题二  loss 小于零 代表什么
'''