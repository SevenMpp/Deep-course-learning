from collections import defaultdict
number_graph = defaultdict(list)
number_graph.update({
    1: [2, 3],
    2: [1, 4],
    3: [1, 5],
    4: [2, 6],
    5: [3, 7],
    7: [5, 8]
})
def bfs(graph,start):
    '''breat first search'''
    visited = [start]
    seen = set()
    while visited:
        print(visited)
        forninter = visited.pop()
        if forninter in seen: continue
        for successor in graph[forninter]:
            if successor in seen:continue
            #print("bfs:",successor)
            visited = [successor] + visited
        seen.add(forninter)
    return seen

def dfs(graph,start):
    '''Deepth first search'''
    visited = [start]
    seen = set()
    while visited:
        print(visited)
        forninter = visited.pop()
        if forninter in seen: continue
        for successor in graph[forninter]:
            if successor in seen:continue    #消除环的问题
            #print("dfs:", successor)
            visited = visited + [successor]
        seen.add(forninter)
    return seen
print(bfs(number_graph,1))
print(dfs(number_graph,1))